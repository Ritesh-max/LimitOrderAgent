package org.afob.execution;

import java.math.BigDecimal;

public final class ExecutionClient {

    /**
     * Execute a buy order
     * @param productId - the product to buy
     * @param amount - the amount to buy
     * @throws ExecutionException
     */
	  
	public void executeOrder(String productId, BigDecimal price) throws ExecutionException {
        // If the price meets or exceeds the default limit price, place a buy order
		 if (price.compareTo(new BigDecimal("100.00")) >= 0) {
	            buy(productId, 10); 
	        } else {
	            sell(productId, 10);
	        }
    }
    public void buy(String productId, int amount) throws ExecutionException {
        System.out.println("Successfully bought " + amount + " units of " + productId);

    }

    /**
     * Execute a sell order
     * @param productId - the product to sell
     * @param amount - the amount to sell
     * @throws ExecutionException
     */
    public void sell(String productId, int amount) throws ExecutionException {
        System.out.println("Successfully sold " + amount + " units of " + productId);
    }


    public static class ExecutionException extends Exception {
        public ExecutionException(String message) {
            super(message);
        }

        public ExecutionException(String message, Throwable cause) {
            super(message, cause);
        }
    }

}
