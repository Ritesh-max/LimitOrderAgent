package org.afob.limit;

import org.junit.Assert;
import org.junit.Test;
import static org.mockito.Mockito.*;

public class LimitOrderAgentTest {
	 private ExecutionClient executionClientMock;
	 private LimitOrderAgent limitOrderAgent;
	 
	 @Before
	    public void setUp() {
	        executionClientMock = mock(ExecutionClient.class);

	        limitOrderAgent = new LimitOrderAgent(executionClientMock);
	        limitOrderAgent.setTargetProductId("AAPL");
	        limitOrderAgent.setLimitPrice(new BigDecimal("150.00"));
	        limitOrderAgent.setAmount(10);
	       
	    }
    @Test
    public void addTestsHere() {
        Assert.fail("not implemented");
    }
    
    @Test
    public void testSellOrderTriggeredWhenPriceBelowLimitPrice() throws ExecutionException {
        BigDecimal price = new BigDecimal("145.00");

        limitOrderAgent.priceTick("AAPL", price);

        verify(executionClientMock, times(1)).sell("AAPL", 10);
        verify(executionClientMock, never()).buy(anyString(), anyInt());
    }
    @Test
    public void testBuyOrderTriggeredWhenPriceAboveLimitPrice() throws ExecutionException {
        BigDecimal price = new BigDecimal("155.00");

        limitOrderAgent.priceTick("AAPL", price);

        verify(executionClientMock, times(1)).buy("AAPL", 10);
        verify(executionClientMock, never()).sell(anyString(), anyInt());
    }
}